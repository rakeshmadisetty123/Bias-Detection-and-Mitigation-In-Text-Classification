from flask import Flask, render_template, request, jsonify
import joblib
import numpy as np

app = Flask(__name__)

# Load the trained model
model = joblib.load('income_prediction_model.pkl')

# Route to render the homepage with the input form
@app.route('/')
def home():
    return render_template('index.html')

# Route to process the prediction
@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get the data from the form
        data = [float(request.form['feature1']),
                float(request.form['feature2']),
                float(request.form['feature3']),
                float(request.form['feature4'])]  # Adjust based on your model's input features

        # Convert the data into a 2D array for prediction
        data = np.array(data).reshape(1, -1)

        # Make prediction
        prediction = model.predict(data)

        # Return the result to the user
        return render_template('index.html', prediction=prediction[0])

    except Exception as e:
        # Handle errors
        return render_template('index.html', error=str(e))

if __name__ == '__main__':
    app.run(debug=True, port=4465)
